<a class="menu-toggle rounded" href="#"><i class="fas fa-bars"></i></a>
        <nav id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand"><a href="#page-top">Choquit</a></li>
                <li class="sidebar-nav-item"><a href="#page-top">Menu</a></li>
                <li class="sidebar-nav-item"><a href="#Acerca">Acerca</a></li>
                <li class="sidebar-nav-item"><a href="#Productos">Productos</a></li>
                <li class="sidebar-nav-item"><a href="#proyectoX">Proyecto</a></li>
                <li class="sidebar-nav-item"><a href="#contactos">Contactos</a></li>
            </ul>
        </nav>