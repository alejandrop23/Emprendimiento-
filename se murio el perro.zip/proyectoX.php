<section class="content-section" id="proyectoX">
            <div class="container px-4 px-lg-5">
                <div class="content-section-heading text-center">
                    <h2 class="mb-5">Nombre del proyecto:</h2>
                </div>
                <div class="row gx-0">
                    <div class="col-lg-6">
                        <a class="portfolio-item" href="#!">
                            <div class="caption">
                                <div class="caption-content">
                                    <div class="h2">Estudio de mercado </div>
                                    <p class="mb-0"><a href="#Productos">productos
                                    </p>
                                      
                                </div>
                            </div>
                            <img class="img-fluid" src="assets/tas.png" 
 width="100%"  alt="..." />
                                       
                        </a>
                    </div>
                    <div class="col-lg-6">
                        <a class="portfolio-item" href="#!">
                            <div class="caption">
                                <div class="caption-content">
                                    <div class="h2">Justificacion</div>
                                    <p class="mb-0">Proponemos lograr un alcance con este proyecto para 
                                    tener exito en este y a futuro lograr un alcance mas grande este producto es poco vendido y puede ser que se pegue mas rapido de lo esperado!</p>
                                </div>
                            </div>
                            <img class="img-fluid" src="assets/negro.jpg" width="150%" alt="..." />
                        </a>
                    </div>
                    <div class="col-lg-6">
                        <a class="portfolio-item" href="#!">
                            <div class="caption">
                                <div class="caption-content">
                                    <div class="h2">vision</div>
                                    <p class="mb-0">La vision seria vender todos los productos y esperar mas de las espectativas que nos proponemos al empezar con este empredimiento y ejecutarlo lo mejor posible y llegar que nuestra empresa cresca lo mejor posible.</p>
                                </div>
                            </div>
                            <img class="img-fluid" src="assets/bl1.jpg"width="150%" alt="..." />
                        </a>
                    </div>
                    <div class="col-lg-6">
                        <a class="portfolio-item" href="#!">
                            <div class="caption">
                                <div class="caption-content">
                                    <div class="h2">mision</div>
                                    <p class="mb-0">.</p>
                                </div>
                            </div>
                            <img class="img-fluid" src="assets/corazon.png"width="100%" alt="..." />
                        </a>
                    </div>
                </div>
            </div>
        </section>