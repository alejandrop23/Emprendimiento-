<section class="contet-sectio bg-light" id="contactos">
           <div class="container px-4 px-lg-5">
  <h2>informacion de contactos </h2>
  <div class="form-group">
    <form method="POST" action="index.php">
      <input type="text" name="nombre" class="form-control">
      <input type="text" name="telefono" class="form-control">
      <input type="email" name="correo" class="form-control">
    <textarea name="mensaje" class="form-control" cols="3", rows="10">
    </textarea>
      <button type="submit" class="btn btn-ligth">Enviar</button>
      <button type="reset" class="btn btn-ligth">Cancelar</button>

    </form>
  </div>


      
</section>