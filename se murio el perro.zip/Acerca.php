<section class="content-section bg-light" id="Acerca">
            <div class="container px-4 px-lg-5 text-center">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-lg-10">
                        <h2>TL !Es un proyecto de empredimiento </h2>
                        <p class="lead mb-5 text-black">
                        <center> <h3>  Grado 10 de la ie Fe y alegria aures 
                          <br>Sus integrantes:
                          <br>Alejandro Pino:  Lider 
                          <br> Mariangel contreras 
                          <br>Jesus arley 
                          <br>Dania martinez 
                          <br>Todo
                         </h3></center>
                            <a href="https://www.facebook.com/">Por si te interesa</a>
                            !
                        </p>
                        <a class="btn btn-dark btn-xl" href="#Productos">Nuestros productos</a>
                      <center><img src="assets/Proyecto.png" width="300px" height="300px"></center>
                      <center><img src="assets/taco.png" width="300px" height="350px"></center>
                    </div>
                </div>
            </div>
        </section>